from django.shortcuts import render, redirect


def paywall(request):
    return render(request, 'helper/paywall.html')

def index(request):
    # Check if user has unlocked the answer
    paid = request.session.get('paid', False)

    if request.method == 'POST':
        question = request.POST.get('question')

        if paid:
            # Show the answer and reset payment
            answer = f"Simulated AI answer to: {question}"
            request.session['paid'] = False
            return render(request, 'helper/index.html', {'answer': answer, 'question': question})
        else:
            # Show paywall if not paid
            return render(request, 'helper/paywall.html', {'question': question})

    return render(request, 'helper/index.html')

   
def pay(request):
    if request.method == 'POST':
        # Mark user as paid
        request.session['paid'] = True
        return redirect('index')

    return redirect('index')
